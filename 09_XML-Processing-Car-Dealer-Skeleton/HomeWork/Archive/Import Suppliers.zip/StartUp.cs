﻿using System;
using System.IO;
using System.Linq;
using CarDealer.Data;
using CarDealer.DTO.ImportDTO;
using CarDealer.Models;
using CarDealer.XMLHelper;

namespace CarDealer
{
    public class StartUp
    {
        public const string ResultDirectoryPath = "../../../Datasets/Results";

        public static void Main(string[] args)
        {

            CarDealerContext context = new CarDealerContext();

            //just in the begining to create DB:
            //ResetDataBase(context);

            var suppliersXml = File.ReadAllText("../../../Datasets/suppliers.xml");
            var carsXml = File.ReadAllText("../../../Datasets/cars.xml");
            var customersXml = File.ReadAllText("../../../Datasets/customers.xml");
            var partsXml = File.ReadAllText("../../../Datasets/parts.xml");
            var salesXml = File.ReadAllText("../../../Datasets/sales.xml");

            //09÷13
            var result = ImportSuppliers(context, suppliersXml);
            Console.WriteLine(result);
        }

        public static void ResetDataBase(CarDealerContext db)
        {
            db.Database.EnsureDeleted();
            Console.WriteLine("DB deleted");
            db.Database.EnsureCreated();
            Console.WriteLine("DB created");

        }

        //Query 9. Import Suppliers
        public static string ImportSuppliers(CarDealerContext context, string inputXml)
        {

            //var result = ImportSuppliers(context, suppliersXml);
            //Console.WriteLine(result);

            const string rootElement = "Suppliers";

            var supplierResult = XMLConverter.Deserializer<ImportSuppliersDto>(inputXml, rootElement);

            var suppliers = supplierResult
                .Select(s => new Supplier
                {
                    Name = s.Name,
                    IsImporter = s.IsImporter
                })
                .ToArray();


            context.Suppliers.AddRange(suppliers);
            int suppliersCount = context.SaveChanges();

            return $"Successfully imported {suppliersCount}";

        }

        //Query 10. Import Parts
        public static string ImportParts(CarDealerContext context, string inputXml)
        {
            //var result = ImportParts(context, partsXml);
            //Console.WriteLine(result);

            const string rootElement = "Parts";

            var partsResult = XMLConverter.Deserializer<ImportPartsDto>(inputXml, rootElement);

            var parts = partsResult
                .Where(p => context.Suppliers.Any(s => s.Id == p.SupplierId))
                .Select(p => new Part
                {
                    Name = p.Name,
                    Price = p.Price,
                    Quantity = p.Quantity,
                    SupplierId = p.SupplierId
                })
                .ToArray();

            context.Parts.AddRange(parts);
            int partsCount = context.SaveChanges();

            return $"Successfully imported {partsCount}";
        }
    }
}