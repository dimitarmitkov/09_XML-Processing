﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using ProductShop.Data;
using ProductShop.Dtos.Import;
using ProductShop.Models;
using ProductShop.XMLHelper;

namespace ProductShop
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            ProductShopContext context = new ProductShopContext();

            //ResetDataBase(context);

            var usersXml = File.ReadAllText("../../../Datasets/users.xml");
            var productsXml = File.ReadAllText("../../../Datasets/products.xml");
            var categoriesXml = File.ReadAllText("../../../Datasets/categories.xml");
            var categoriesProductsXml = File.ReadAllText("../../../Datasets/categories-products.xml");

            var result = ImportCategoryProducts(context, categoriesProductsXml);

            Console.WriteLine(result);
        }

        public static void ResetDataBase(ProductShopContext db)
        {
            db.Database.EnsureDeleted();
            Console.WriteLine("DB deleted");
            db.Database.EnsureCreated();
            Console.WriteLine("DB created");

        }

        //Query 1. Import Users
        public static string ImportUsers(ProductShopContext context, string inputXml)
        {

            //var result = ImportUsers(context, usersXml);

            const string rootElement = "Users";

            var usersResult = XMLConverter.Deserializer<ImportUserDto>(inputXml, rootElement);

            //this below is first version of input users by foreach

            //var users = new List<User>();

            //foreach (var importUserDto in users)
            //{
            //    var user = new User
            //    {
            //        FirstName = importUserDto.FirstName,
            //        LastName = importUserDto.LastName,
            //        Age = importUserDto.Age

            //    };
            //    users.Add(user);
            //}

            var users = usersResult
                .Select(u => new User
                {
                    FirstName = u.FirstName,
                    LastName = u.LastName,
                    Age = u.Age
                })
                .ToArray();


            context.Users.AddRange(users);
            int usersCount = context.SaveChanges();

            return $"Successfully imported {usersCount}";
        }

        //Query 2. Import Products
        public static string ImportProducts(ProductShopContext context, string inputXml)
        {

            //var result = ImportProducts(context, productsXml);

            const string rootElement = "Products";

            var productsResult = XMLConverter.Deserializer<ImportProductDto>(inputXml, rootElement);

            var products = productsResult
                .Select(p => new Product
                {
                    Name = p.Name,
                    Price = p.Price,
                    SellerId = p.SellerId,
                    BuyerId = p.BuyerId
                })
                .ToArray();

            context.Products.AddRange(products);
            int productsCount = context.SaveChanges();

            return $"Successfully imported {productsCount}";
        }

        //Query 3. Import Categories
        public static string ImportCategories(ProductShopContext context, string inputXml)
        {

            //var result = ImportCategories(context, categoriesXml);

            const string rootElement = "Categories";

            var categoryResult = XMLConverter.Deserializer<CategoryDto>(inputXml, rootElement);

            //var categories = new List<Category>();

            //foreach (var cat in categoryResult)
            //{
            //    if (cat.Name == null)
            //    {
            //        continue;
            //    }

            //    var category = new Category
            //    {
            //        Name = cat.Name,
            //    };

            //    categories.Add(category);
            //}

            var categories = categoryResult
                .Where(c => c.Name != null)
                .Select(c => new Category
                {
                    Name = c.Name
                })
                .ToArray();

            context.Categories.AddRange(categories);
            int categoriesCount = context.SaveChanges();

            return $"Successfully imported {categoriesCount}";
        }

        //Query 4. Import Categories and Products
        public static string ImportCategoryProducts(ProductShopContext context, string inputXml)
        {
            const string rootElement = "CategoryProducts";

            var catProdResult = XMLConverter.Deserializer<CategoriesProductsDto>(inputXml, rootElement);

            var categoriesProducts = catProdResult
                .Where(c => context.Categories.Any(s => s.Id == c.CategoryId) && context.Products.Any(s => s.Id == c.ProductId))
                .Select(cp => new CategoryProduct
                {
                    CategoryId = cp.CategoryId,
                    ProductId = cp.ProductId,
                })
                .ToArray();


            //other possible version
            //var categoriesProducts = new List<CategoryProduct>();

            //foreach (var catProd in catProdResult)
            //{
            //    var doesExist = context.Products.Any(x => x.Id == catProd.ProductId) && context.Categories.Any(x => x.Id == catProd.CategoryId);

            //    if (!doesExist)
            //    {
            //        continue;
            //    }

            //    var categoryProduct = new CategoryProduct
            //    {
            //        CategoryId = catProd.CategoryId,
            //        ProductId = catProd.ProductId
            //    };

            //    categoriesProducts.Add(categoryProduct);
            //}

            context.CategoryProducts.AddRange(categoriesProducts);
            int catProdCount = context.SaveChanges();


            return $"Successfully imported {catProdCount}";
        }
    }
}