﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using ProductShop.Data;
using ProductShop.Dtos.Import;
using ProductShop.Models;
using ProductShop.XMLHelper;

namespace ProductShop
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            ProductShopContext context = new ProductShopContext();

            //ResetDataBase(context);

            var usersXml = File.ReadAllText("../../../Datasets/users.xml");

            var result = ImportUsers(context, usersXml);

            Console.WriteLine(result);
        }

        public static void ResetDataBase(ProductShopContext db)
        {
            db.Database.EnsureDeleted();
            Console.WriteLine("DB deleted");
            db.Database.EnsureCreated();
            Console.WriteLine("DB created");

        }

        public static string ImportUsers(ProductShopContext context, string inputXml)
        {
            const string rootElement = "Users";

            var usersResult = XMLConverter.Deserializer<ImportUserDto>(inputXml, rootElement);

            //this below is first version of input users by foreach

            //var users = new List<User>();

            //foreach (var importUserDto in users)
            //{
            //    var user = new User
            //    {
            //        FirstName = importUserDto.FirstName,
            //        LastName = importUserDto.LastName,
            //        Age = importUserDto.Age

            //    };
            //    users.Add(user);
            //}

            var users = usersResult
                .Select(u => new User
                {
                    FirstName = u.FirstName,
                    LastName = u.LastName,
                    Age = u.Age
                })
                .ToArray();


            context.Users.AddRange(users);
            int usersCount = context.SaveChanges();

            return $"Successfully imported {usersCount}";
        }
    }
}